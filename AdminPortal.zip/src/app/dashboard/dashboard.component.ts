import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {






  zoomcustom = 11;

radius=1000;
  icondisaster = './../../assets/icons/fire.png';
  iconRescue = './../../assets/icons/rescue_map_icon3.png';
  lat: number = 12.826139;
  lng: number = 77.679791;
  danger: { "title": string; "desc": string; }[];
  success: { "title": string; "desc": string; }[];


  constructor() {
    this.success = [
      { "title": "volunteers added", "desc": "21 volunteers have been added for help near HSR layout." },
      { "title": "12 people rescued", "desc": "12 people have been rescued from a building at fire near BTM layout." }
    ];
    this.danger = [
      { "title": "Gas explosion near Kormangala", "desc": "20 people are stuck in a building that caught fire in Kormangala." },
      { "title": "Camp 2102 need medical help", "desc": "Camp 2102 near Banashankari need medical equipments asap." }
    ];
  }

  zoom: number = 13;

  markers: marker[] = [

    {

      lat: 12.839024,
      lng: 77.656472,

    },

    {

      lat: 12.841320,

      lng: 77.649813

    },

    {

      lat: 12.828097,

      lng: 77.649469

    },

    {

      lat: 12.831109,

      lng: 77.678052

    },

    {

      lat: 12.832609,

      lng: 77.672926

    },




    {

      lat: 12.875288,

      lng: 77.672790

    },

    {

      lat: 12.876589,

      lng: 77.685415

    },

    {

      lat: 12.869134,

      lng: 77.680680

    },

    {

      lat: 12.880022,

      lng: 77.684201

    },

    {

      lat: 12.878071,

      lng: 77.695048

    },

    {

      lat: 12.810367,

      lng: 77.679782

    },

    {

      lat: 12.811313,

      lng: 77.689492

    },

    {

      lat: 12.801348,

      lng: 77.690002

    },

    {

      lat: 12.806095,

      lng: 77.678740

    },

    {

      lat: 12.816472,

      lng: 77.693505

    }

  ];


  // just an interface for type safety.


  ngOnInit() {

    setInterval(()=>{
      this.radius+=100;
    }1000);
  }

  public lineChartData: Array<any> = [
    [65, 59, 45, 67, 56, 55, 40],
    [28, 48, 40, 19, 200, 27, 68],
    [24, 28, 42, 33, 46, 36, 45]
  ];
  public lineChartLabels: Array<any> = ['Fire', 'water', 'gas'];
  public lineChartType: string = 'line';
  public pieChartType: string = 'pie';

  // Pie
  public pieChartLabels: string[] = ['People rescued', 'People helped', 'Volunteers'];
  public pieChartData: number[] = [300, 500, 100];

  public randomizeType(): void {
    this.lineChartType = this.lineChartType === 'line' ? 'bar' : 'line';
    this.pieChartType = this.pieChartType === 'doughnut' ? 'pie' : 'doughnut';
  }

  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  public barChartOptions: any = {
    scaleShowVerticalLines: false
  };
  public barChartLabels: string[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  public barChartType: string = 'bar';
  public barChartLegend: boolean = true;

  public barChartData: any[] = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'People affected' },
    { data: [5, 3, 4, 6, 5, 7, 9], label: 'No. of disasters' }
  ];
  onMouseOver(infoWindow) {
    infoWindow.open();
  }
}

interface marker {
  lat: number;
  lng: number;

}