import { TestBed, inject } from '@angular/core/testing';

import { GraphHandlerService } from './graph-handler.service';

describe('GraphHandlerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GraphHandlerService]
    });
  });

  it('should be created', inject([GraphHandlerService], (service: GraphHandlerService) => {
    expect(service).toBeTruthy();
  }));
});
