import { DashboardComponent } from './dashboard/dashboard.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnalysisComponent } from './analysis/analysis.component';
import { MapsComponent } from './maps/maps.component';

const routes: Routes = [
  {path:'dashboard',component:DashboardComponent},
  {path:'',component:AnalysisComponent},
  {path:'analysis',component:AnalysisComponent},
  {path:'maps',component:MapsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
