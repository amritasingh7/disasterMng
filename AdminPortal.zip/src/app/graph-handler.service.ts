import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GraphHandlerService {

  options: { headers: { "Content-Type": string; }; };
 
  constructor(private http:HttpClient) {
    this.options = {
      headers:{
        "Content-Type":"application/json"
      }
    }
  }

  getFireSensor(){
    return this.http.post("http://disastermgm.eu-gb.mybluemix.net/getSensor",{"type":"fire"},this.options);
  }

  getWaterSensor(){
    return this.http.post("http://disastermgm.eu-gb.mybluemix.net/getSensor",{"type":"water"},this.options);
  }

  getGasSensor(){
    return this.http.post("http://disastermgm.eu-gb.mybluemix.net/getSensor",{"type":"gas"},this.options);
  }
}
