import { HttpClient } from '@angular/common/http';
import { GraphHandlerService } from './../graph-handler.service';
import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js';

@Component({
    selector: 'app-analysis',
    templateUrl: './analysis.component.html',
    styleUrls: ['./analysis.component.css']
})
export class AnalysisComponent implements OnInit {

    firelabel: any = new Array();
    firedata: any = new Array();
    waterlabel: any = new Array();
    waterdata: any = new Array();
    gaslabel: any = new Array();
    gasdata: any = new Array();
    start = 0;
    end = 5;
    constructor(private graphHandler: GraphHandlerService, private http: HttpClient) {

    }

    ngOnInit() {

        ///////////////////////////Gas Sensor Live reading Api////////////////////////////////
        this.http.post("https://disastermgm.eu-gb.mybluemix.net/getSensor", { "type": "gas" }).subscribe((data: any) => {
            console.log(data);

            var dps = []; // dataPoints

            var chart = new CanvasJS.Chart("chartContainergas", {
                title: {
                    text: "Gas Sensor Live Reading"
                },
                axisY: {
                    includeZero: false
                },
                data: [{
                    type: "line",
                    dataPoints: dps
                }]
            });

            var updateInterval = 700;
            var dataLength = 10; // number of dataPoints visible at any point
            var counter = 1;

            var updateChart = function (count) {

                dps.push({
                    x: count,
                    y: data[count].value
                });

                if (dps.length > dataLength) {
                    dps.shift();
                }

                chart.render();
            };

            updateChart(counter);

            counter++;

            var id =setInterval(() => {
                updateChart(counter);
                counter++;
                if(counter==49){
                    clearInterval(id);
                }
            }, updateInterval);

        })


        ///////////////////////////Gas Sensor Ends////////////////////////////////==============



        ///////////////////////////Fire Sensor Live reading Api////////////////////////////////

        this.http.post("https://disastermgm.eu-gb.mybluemix.net/getSensor", { "type": "fire" }).subscribe((data: any) => {
            console.log(data);

            var dps = []; // dataPoints

            var chart = new CanvasJS.Chart("chartContainerfire", {
                title: {
                    text: "Fire Sensor Live Reading"
                },
                axisY: {
                    includeZero: false
                },
                data: [{
                    type: "line",
                    dataPoints: dps
                }]
            });

            var updateInterval = 600;
            var dataLength = 10; // number of dataPoints visible at any point
            var counter = 1;

            var updateChart = function (count) {

                dps.push({
                    x: count,
                    y: data[count].value
                });

                if (dps.length > dataLength) {
                    dps.shift();
                }

                chart.render();
            };

            updateChart(counter);

            counter++;

            var id =setInterval(() => {
                updateChart(counter);
                counter++;
                if(counter==49){
                    clearInterval(id);
                }
            }, updateInterval);

        })

        ///////////////////////////Fire Sensor Ends////////////////////////////////================




        ///////////////////////////Water Sensor Live readinf Api////////////////////////////////

        this.http.post("https://disastermgm.eu-gb.mybluemix.net/getSensor", { "type": "water" }).subscribe((data: any) => {
            console.log(data);

            var dps = []; // dataPoints

            var chart = new CanvasJS.Chart("chartContainerwater", {
                title: {
                    text: "Water Sensor Live Reading"
                },
                axisY: {
                    includeZero: false
                },
                data: [{
                    type: "line",
                    dataPoints: dps
                }]
            });

            var updateInterval = 900;
            var dataLength = 10; // number of dataPoints visible at any point
            var counter = 1;

            var updateChart = function (count) {

                dps.push({
                    x: count,
                    y: data[count].value
                });

                if (dps.length > dataLength) {
                    dps.shift();
                }

                chart.render();
            };

            updateChart(counter);

            counter++;

            var id =setInterval(() => {
                updateChart(counter);
                counter++;
                if(counter==49){
                    clearInterval(id);
                }
            }, updateInterval);

        })

        ///////////////////////////Water Sensor ends////////////////////////////////===============


    }
}