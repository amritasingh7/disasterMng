// =================================================================
// get the packages we need ========================================
// =================================================================
var express 	= require('express');
var app         = express();
var bodyParser  = require('body-parser');
var morgan      = require('morgan');
var mongoose    = require('mongoose');

var jwt    = require('jsonwebtoken'); // used to create, sign, and verify tokens
var config = require('./config'); // get our config file
var User   = require('./app/models/user'); // get our mongoose model
var cors = require('cors')
var app = express();

var Sensor = require('./app/models/sensor');
var UserHelp = require('./app/models/userHelp');

app.use(cors());



// =================================================================
// configuration ===================================================
// =================================================================
var port = process.env.PORT || 8081; // used to create, sign, and verify tokens
mongoose.connect(config.database,function(err){
	if(err)
	throw err;
	else{
		console.log("connected to db");
	}
}); // connect to database
app.set('superSecret', config.secret); // secret variable

// use body parser so we can get info from POST and/or URL parameters
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(bodyParser.text());
app.use(bodyParser.raw());


// app.use(express.bodyParser());

// use morgan to log requests to the console
app.use(morgan('dev'));


// =================================================================
// sensor routes ===================================================
// =================================================================
app.post('/postSensor', function(req, res) {


	

var obj=JSON.parse(req.body);

console.log(obj);
console.log(obj.type);

	var sensor = new Sensor({ 
		id: obj.id, 
		type: obj.type,
		address: obj.address,
		lat: obj.lat,
		lng: obj.lng,
		value: obj.value
	});

	console.log(sensor);

	sensor.save(function(err) {
		if (err) throw err;

		console.log('Sensor data saved successfully');
		res.json({ success: true });
	});

	
});
app.post('/getSensor', function(req, res) {
	console.log(req.body.type);

	Sensor.find({
		type:req.body.type
	},function(err,data){
		if(err) throw err;

		console.log(data);
		res.json(data);
	})
	
});









// =================================================================
// sensor routes ends ==============================================
// =================================================================



app.post('/userHelp', function(req, res) {
	console.log(req.body);

	var userHelpobj = new UserHelp(req.body);

	userHelpobj.save(function(err) {
		if (err) throw err;

		console.log('user Help data saved successfully');
		res.json({ success: true });
	});

	
});

app.get('/userHelpData', function(req, res) {

	UserHelp.find({},function(err,data){
		res.json(data);
	})
	
});













// =================================================================
// routes ==========================================================
// =================================================================
app.post('/signup', function(req, res) {
	console.log(req.body);
	console.log(req.body.email);
	console.log(req.body.password);
	console.log(req.body.phoneNumber);
	console.log(req.body.address);
	console.log(req.body.gender);

	User.findOne({
		email: req.body.email
	}, function(err, user) {
		console.log(user);

		if (err) throw err;
		if (user) {
			console.log(user);
			res.json({ success: false, message: 'Signup failed.User exists.' });

		}
		else{

		

			var user = new User({ 
				email: req.body.email, 
				password: req.body.password,
				mobileNumber: req.body.phoneNumber,
				address: req.body.address,
				gender: req.body.gender
			});

			console.log(user);

			user.save(function(err) {
				if (err) throw err;
		
				console.log('User saved successfully');
				res.json({ success: true });
			});

		

	}

	});
	
});


app.get('/', function(req, res) {
	res.send('Hello! The API is at bluemix' + port );
});

// ---------------------------------------------------------
// get an instance of the router for api routes
// ---------------------------------------------------------
var apiRoutes = express.Router(); 

// ---------------------------------------------------------
// authentication (no middleware necessary since this isnt authenticated)
// ---------------------------------------------------------

apiRoutes.post('/authenticate', function(req, res) {
	console.log(req.body.email);
	console.log(req.body.password);
	// find the user
	User.findOne({
		email: req.body.email
	}, function(err, user) {

		if (err) throw err;

		if (!user) {
			res.json({ success: false, message: 'Authentication failed. User not found.' });
		} else if (user) {

			// check if password matches
			if (user.password != req.body.password) {
				res.json({ success: false, message: 'Authentication failed. Wrong password.' });
			} else {

				// if user is found and password is right
				// create a token
				var payload = {
					admin: user.admin	
				}
				var token = jwt.sign(payload, app.get('superSecret'), {
					expiresIn: 86400 // expires in 24 hours
				});

				res.json({
					success: true,
					message: 'Enjoy your token!',
					token: token
				});
			}		

		}

	});
});

// ---------------------------------------------------------
// route middleware to authenticate and check token
// ---------------------------------------------------------
apiRoutes.use(function(req, res, next) {

	// check header or url parameters or post parameters for token
	var token = req.body.token || req.param('token') || req.headers['x-access-token'];

	// decode token
	if (token) {

		// verifies secret and checks exp
		jwt.verify(token, app.get('superSecret'), function(err, decoded) {			
			if (err) {
				return res.json({ success: false, message: 'Failed to authenticate token.' });		
			} else {
				// if everything is good, save to request for use in other routes
				req.decoded = decoded;	
				next();
			}
		});

	} else {

		// if there is no token
		// return an error
		return res.status(403).send({ 
			success: false, 
			message: 'No token provided.'
		});
		
	}
	
});



// ---------------------------------------------------------
// authenticated routes
// ---------------------------------------------------------
apiRoutes.get('/', function(req, res) {
	res.json({ message: 'Welcome to https://disastermgm.eu-gb.mybluemix.net/!' });
});

apiRoutes.post('/userData', function(req, res) {
	User.find({email:req.body.email}, function(err, user) {
		res.json(user);
	});
});

apiRoutes.get('/check', function(req, res) {
	res.json(req.decoded);
});

app.use('/api', apiRoutes);

// =================================================================
// start the server ================================================
// =================================================================
app.listen(process.env.PORT || port);
console.log('Magic happens at https://disastermgm.eu-gb.mybluemix.net/:' + port);
