module.exports = {

	'secret': 'ilovescotchyscotch',
	'database': 'mongodb://sharang:sharang1@ds161102.mlab.com:61102/disastermgm'

};