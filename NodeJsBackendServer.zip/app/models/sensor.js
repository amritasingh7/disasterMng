var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// set up a mongoose model
module.exports = mongoose.model('Sensor', new Schema({ 
    id: String, 
    type:String,
	address: String,
    lat:Number,
    lng:Number,
    value:Number
}));